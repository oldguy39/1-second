package com.john.onesecoff;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private Button camButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 120, 48, 48);

        TextView text = new TextView(this);
        text.setTextSize(20);
        text.setText("One Second Off\n\n"
                + "1. Tap the first button, find \"One Second Off\" "
                + "(under Downloaded apps / Installed apps) and switch it on.\n\n"
                + "2. Tap the second button and allow the camera, so the screen "
                + "stays on while you look at the phone lying face up.\n");

        Button button = new Button(this);
        button.setText("Open Accessibility settings");
        button.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        camButton = new Button(this);
        camButton.setOnClickListener(v ->
                requestPermissions(new String[]{Manifest.permission.CAMERA}, 1));

        layout.addView(text);
        layout.addView(button);
        layout.addView(camButton);
        setContentView(layout);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCamButton();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        updateCamButton();
    }

    private void updateCamButton() {
        boolean ok = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        camButton.setText(ok ? "Camera allowed" : "Allow camera (face check)");
        camButton.setEnabled(!ok);
    }
}
