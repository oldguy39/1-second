package com.john.onesecoff;

import android.Manifest;
import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.PowerManager;
import android.view.accessibility.AccessibilityEvent;

/**
 * Turns the screen off ~1 second after the phone is laid down flat.
 *
 *  - FACE DOWN: screen off after 1 second, same as before.
 *  - FACE UP:   takes a quick look with the front camera first.
 *               If it sees a face, the screen stays on and it looks again every 5 seconds.
 *               When nobody is looking any more, the screen goes off.
 *
 * Battery design:
 *  - The motion sensor is switched on ONLY while the screen is on.
 *    When the screen is off, this app does nothing at all.
 *  - The camera is used only while the phone lies still and face up with the screen on,
 *    for about half a second at a time, using its smallest picture size.
 *  - No foreground notification, no timers while the screen is off.
 */
public class LockService extends AccessibilityService implements SensorEventListener {

    // ---- Tuning (change these if needed) ----
    private static final long  STILL_MS   = 1000;  // how long it must lie still before acting
    private static final long  RECHECK_MS = 5000;  // how often to look again while a face is seen
    private static final float STILL_TOL  = 0.15f; // jitter allowed while "still" (m/s^2)
    private static final float FLAT_Z     = 9.3f;  // |z| above this = lying flat (within ~18 degrees)
    private static final float FLAT_XY    = 2.5f;  // sideways tilt allowance
    private static final float MOVE_TOL   = 0.8f;  // movement that counts as "picked up / being set down"

    private SensorManager sensorManager;
    private Sensor accel;
    private PowerManager.WakeLock keepOn;
    private FaceCheck faceCheck;

    private boolean listening = false;
    private boolean armed = false;       // only true after the phone has moved or been tilted
    private boolean haveBase = false;
    private boolean checking = false;    // a camera look is under way
    private float bx, by, bz;
    private long stillSinceNs = 0;
    private long nextCheckNs = 0;
    private long lastNs = 0;

    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (Intent.ACTION_SCREEN_ON.equals(i.getAction())) startWatching();
            else if (Intent.ACTION_SCREEN_OFF.equals(i.getAction())) stopWatching();
        }
    };

    @Override
    @SuppressWarnings("deprecation")
    protected void onServiceConnected() {
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        faceCheck = new FaceCheck(this);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        keepOn = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "onesecoff:looking");
        keepOn.setReferenceCounted(false);

        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(screenReceiver, filter);
        }

        if (pm.isInteractive()) startWatching();
    }

    private boolean cameraAllowed() {
        return faceCheck != null && faceCheck.available()
                && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private void startWatching() {
        if (listening || accel == null) return;
        armed = false;
        haveBase = false;
        nextCheckNs = 0;
        sensorManager.registerListener(this, accel, SensorManager.SENSOR_DELAY_NORMAL);
        listening = true;
    }

    private void stopWatching() {
        if (listening) {
            sensorManager.unregisterListener(this);
            listening = false;
        }
        if (checking) faceCheck.cancel();
        releaseScreen();
    }

    private void lockNow() {
        stopWatching();
        performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN); // fingerprint/face unlock still works
    }

    private void holdScreen() {
        if (keepOn != null) keepOn.acquire(RECHECK_MS + 3000); // lasts until just past the next look
    }

    private void releaseScreen() {
        if (keepOn != null && keepOn.isHeld()) keepOn.release();
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        float x = e.values[0], y = e.values[1], z = e.values[2];
        boolean flat = Math.abs(z) > FLAT_Z && Math.hypot(x, y) < FLAT_XY;
        lastNs = e.timestamp;

        if (!haveBase) {
            bx = x; by = y; bz = z;
            stillSinceNs = e.timestamp;
            haveBase = true;
            if (!flat) armed = true;
            return;
        }

        float d = Math.max(Math.abs(x - bx), Math.max(Math.abs(y - by), Math.abs(z - bz)));

        // Arm only after real movement or tilt, so waking the phone while it's
        // already on the table (to read it there) does NOT shut it off.
        if (d > MOVE_TOL || !flat) armed = true;

        if (d > STILL_TOL || !flat) {
            bx = x; by = y; bz = z;
            stillSinceNs = e.timestamp;
            nextCheckNs = 0;       // moved: next time it settles, look right away
            releaseScreen();       // in your hand the normal screen timeout applies
            return;
        }

        if (e.timestamp - stillSinceNs < STILL_MS * 1_000_000L) return;

        // Face down: nobody can be looking at it.
        if (z < 0) {
            if (armed) lockNow();
            return;
        }

        // Face up without camera permission: behave like the old version.
        if (!cameraAllowed()) {
            if (armed) lockNow();
            return;
        }

        if (checking || e.timestamp < nextCheckNs) return;

        checking = true;
        faceCheck.start(faceSeen -> {
            checking = false;
            if (!listening) return;                 // screen already went off
            nextCheckNs = lastNs + RECHECK_MS * 1_000_000L;
            if (faceSeen) {
                holdScreen();
            } else {
                releaseScreen();
                if (armed) lockNow();
            }
        });
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    @Override
    public void onDestroy() {
        stopWatching();
        try { unregisterReceiver(screenReceiver); } catch (Exception ignored) { }
        super.onDestroy();
    }
}
